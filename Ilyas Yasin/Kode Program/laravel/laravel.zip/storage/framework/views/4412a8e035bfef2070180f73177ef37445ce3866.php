<div class="form-group <?php echo e($errors->has('jenis_tanaman') ? 'has-error' : ''); ?>">
    <label for="jenis_tanaman" class="col-md-4 control-label"><?php echo e('Jenis Tanaman'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="jenis_tanaman" type="text" id="jenis_tanaman" value="<?php echo e(isset($jenis_tanaman->jenis_tanaman) ? $jenis_tanaman->jenis_tanaman : ''); ?>" >
        <?php echo $errors->first('jenis_tanaman', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('jmlh_ppm') ? 'has-error' : ''); ?>">
    <label for="jmlh_ppm" class="col-md-4 control-label"><?php echo e('Jmlh Ppm'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="jmlh_ppm" type="text" id="jmlh_ppm" value="<?php echo e(isset($jenis_tanaman->jmlh_ppm) ? $jenis_tanaman->jmlh_ppm : ''); ?>" >
        <?php echo $errors->first('jmlh_ppm', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
