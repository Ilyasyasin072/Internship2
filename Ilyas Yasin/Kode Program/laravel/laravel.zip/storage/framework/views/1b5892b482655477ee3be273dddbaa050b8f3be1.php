<div class="form-group <?php echo e($errors->has('tanggal') ? 'has-error' : ''); ?>">
    <label for="tanggal" class="col-md-4 control-label"><?php echo e('Tanggal'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="tanggal" type="date" id="tanggal" value="<?php echo e(isset($jenis_ph->tanggal) ? $jenis_ph->tanggal : ''); ?>" >
        <?php echo $errors->first('tanggal', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('jenis_tanaman') ? 'has-error' : ''); ?>">
    <label for="jenis_tanaman" class="col-md-4 control-label"><?php echo e('Jenis Tanaman'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="jenis_tanaman" type="text" id="jenis_tanaman" value="<?php echo e(isset($jenis_ph->jenis_tanaman) ? $jenis_ph->jenis_tanaman : ''); ?>" >
        <?php echo $errors->first('jenis_tanaman', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
