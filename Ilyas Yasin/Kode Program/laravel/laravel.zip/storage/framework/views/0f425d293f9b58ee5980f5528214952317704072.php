<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
                         <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Striped Table with Hover</h4>
                                <p class="category">Here is a subtitle for this table</p>
                         <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th><th>X</th><th>Y</th>
                                        <th>X2</th>
                                        <th>Y2</th>
                                         <th>XY</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $forecasting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(isset($loop->iteration) ? $loop->iteration : $item->id); ?></td>
                                        <td><?php echo e($item->dosis); ?></td>
                                        <td><?php echo e($item->ppm); ?></td>
                                        <td><?php echo e($item->dosis *  $item->dosis); ?></td>
                                        <td><?php echo e($item->ppm * $item->ppm); ?></td>
                                        <td><?php echo e($item->ppm * $item->dosis); ?></td>
                                          
                                        <!-- <td>
                                            <a href="<?php echo e(url('/forecasting/' . $item->id)); ?>" title="View forecasting"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="<?php echo e(url('/forecasting/' . $item->id . '/edit')); ?>" title="Edit forecasting"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                                            <form method="POST" action="<?php echo e(url('/forecasting' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete forecasting" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td> -->
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                               <div class="table-responsive">
                            <table class="table">
                            <thead>
                                    <tr>
                                         <th>Jumlah X</th>
                                          <th>Jumlah Y</th>
                                           <th>Jumlah X2</th>
                                            <th>Jumlah Y2</th>
                                             <th>Jumlah XY</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php echo e($jumlahx); ?></td>
                                         <td><?php echo e($jumlahy); ?></td>
                                         <td><?php echo e($x2); ?></td>
                                         <td><?php echo e($y2); ?></td>
                                         <td><?php echo e($xy); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                              <div class="table-responsive">
                            <table class="table">
                            <thead>
                                    <tr>
                                        <th>Menghitung Nilai Miring = b</th>
                                       <th>Nilai b</th>
                                        <th>Nilai b</th>
                                         <th>Menghitung Nilai Miring = a</th>
                                         <th>Menentukan Besar Kesalahan Standar Estimasi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php echo e($b1 = $count * $xy - $jumlahx * $jumlahy); ?></td>
                                             <td><?php echo e($b2 = $count * $x2 - ($jumlahx * $jumlahx)); ?></td> 
                                           <td> <?php echo e($b1 / $b2); ?> </td>
                                            <td><?php echo e($a = $jumlahy - 200 * $jumlahx); ?></td>
                                            <td><?php echo e($y2 - 0 * $jumlahy - 200 * $xy / $count - 2); ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                              <div class="table-responsive">
                            <table class="table">
                            <thead>
                                    <tr>
                                        <th>Hasil R1</th>
                                        <th>Hasil R2</th>
                                        <th>Hasil R3</th>
                                         <th>Hasil Koefisien Determinasi R1 / R2 * R3</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php echo e($r1 = $count * $xy -  $jumlahx * $jumlahy); ?></td>
                                         <td><?php echo e($r2 = ($count * $x2 - $jumlahx * $jumlahx)*0.5); ?></td>
                                         <td><?php echo e($r3 = ($count * $y2 - $jumlahy * $jumlahy)*0.5); ?></td>
                                         <td><?php echo e($r1 / $r2 * $r3); ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>