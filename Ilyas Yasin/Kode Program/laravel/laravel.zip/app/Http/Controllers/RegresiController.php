<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegresiController extends Controller
{
    public function hitung(){
    }
}
